﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Sprite;
using MonoGameLibrary.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonogameBreakout
{
    enum BallState { OnPaddle, Launched };

    class Ball : DrawableSprite
    {

        GameConsole console;

        protected BallState _mstate; //Private instance data member _m
        public BallState State
        {
            get { return _mstate; }
            protected set
            {
                if (this._mstate != value)
                { this._mstate = value; }
            }
        }

        public Ball(Game game) : base(game)
        {
            console = (GameConsole)this.Game.Services.GetService<IGameConsole>(); //Needed to be Cast so add (GameConsole)
            if(console == null)
            {
                console = new GameConsole(this.Game);
                this.Game.Components.Add(console);
            }
            this.State = BallState.OnPaddle;
            console.GameConsoleWrite("Ball State: " + this.State.ToString());

        }

        public void LaunchBall(GameTime gameTime)
        {
            this.Speed = 190;
            this.Direction = new Vector2(1, 1);
            this.State = BallState.Launched;
            this.console.GameConsoleWrite("Ball Launched " + gameTime.TotalGameTime.ToString());
        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("ballSmall");
            this.Location = new Vector2(100, 100);
            //this.ShowMarkers = true;
            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            if (this.State == BallState.OnPaddle)
            {
                return;
            }
            this.Location += this.Direction * (this.Speed * gameTime.ElapsedGameTime.Milliseconds / 1000);

            //bounce off wall
            //Left and Right
            if ((this.Location.X + this.spriteTexture.Width > this.Game.GraphicsDevice.Viewport.Width)
                ||
                (this.Location.X < 0))
            {
                this.Direction.X *= -1; //reflect in the X
            }
            //bottom Miss
            if (this.Location.Y + this.spriteTexture.Height > this.Game.GraphicsDevice.Viewport.Height)

            {
               // this.resetBall(gameTime);
            }

            //Top
            if (this.Location.Y < 0)
            {
                this.Direction.Y *= -1;
            }

            base.Update(gameTime);
        }
    }
}
