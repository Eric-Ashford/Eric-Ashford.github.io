﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Sprite;
using MonoGameLibrary.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MonogameBreakout
{
    class Paddle : DrawableSprite
    {
        GameConsole console;

        public Paddle(Game game, Ball ball) : base(game)
        {
            console = (GameConsole)this.Game.Services.GetService<IGameConsole>(); //Needed to be Cast so add (GameConsole)
            if (console == null)
            {
                console = new GameConsole(this.Game);
                this.Game.Components.Add(console);
            }
          

        }

        protected override void LoadContent()
        {
            this.spriteTexture = this.Game.Content.Load<Texture2D>("paddleSmall");
            this.Location = new Vector2(300, 450);
            //this.ShowMarkers = true;
            base.LoadContent();
        }
    }
}
